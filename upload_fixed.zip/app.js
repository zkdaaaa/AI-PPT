// Simple CSV parser (no external dep)
function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  const headers = lines[0].split(',');
  const rows = lines.slice(1).map(l => {
    const cols = l.split(',');
    const obj = {};
    headers.forEach((h,i)=> obj[h.trim()] = cols[i] !== undefined ? cols[i].trim() : '');
    return obj;
  });
  return {headers, rows};
}

// Type detection: try date vs number vs string
function profileColumns(headers, rows) {
  const types = {};
  headers.forEach(h => {
    let isNum = true, isDate = true;
    for (let r of rows) {
      const v = r[h];
      if (v === undefined || v === '') continue;
      if (isNum && isNaN(Number(v))) isNum = false;
      if (isDate && isNaN(Date.parse(v))) isDate = false;
    }
    types[h] = isDate ? 'date' : (isNum ? 'number' : 'string');
  });
  return types;
}

// Recommend chart: date+number -> line; string+number -> bar (or pie if <=6 categories and sums to ~1)
function recommendSpec(headers, rows, types) {
  // find candidates
  const dateCols = headers.filter(h => types[h]==='date');
  const numCols  = headers.filter(h => types[h]==='number');
  const strCols  = headers.filter(h => types[h]==='string');
  // CSV to array of objects with parsed types
  const data = rows.map(r => {
    const o = {};
    headers.forEach(h => {
      if (types[h]==='number') o[h] = Number(r[h]);
      else if (types[h]==='date') o[h] = r[h];
      else o[h] = r[h];
    });
    return o;
  });

  // Heuristic 1: time series
  if (dateCols.length>=1 && numCols.length>=1) {
    const x = dateCols[0], y = numCols[0];
    return {
      spec: {
        $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
        data: { values: data },
        mark: 'line',
        encoding: {
          x: { field: x, type:'temporal' },
          y: { field: y, type:'quantitative' },
          tooltip: headers.map(h=>({field:h, type: types[h]==='number'?'quantitative':(types[h]==='date'?'temporal':'nominal')}))
        }
      },
      type: 'line',
      x, y
    };
  }

  // Heuristic 2: category + value
  if (strCols.length>=1 && numCols.length>=1) {
    const cat = strCols[0], val = numCols[0];
    // check if values sum near 1 for pie
    const sum = data.reduce((s,d)=> s + (Number(d[val])||0), 0);
    const nearOne = sum>0.98 and sum<1.02;
    if (nearOne && data.length<=6) {
      return {
        spec: {
          $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
          data: { values: data },
          mark: { type:'arc', outerRadius:100 },
          encoding: {
            theta: { field: val, type:'quantitative' },
            color: { field: cat, type:'nominal' },
            tooltip: [{field:cat,type:'nominal'},{field:val,type:'quantitative'}]
          },
          view: { stroke: null }
        },
        type: 'pie',
        x: cat, y: val
      };
    } else {
      return {
        spec: {
          $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
          data: { values: data },
          mark: 'bar',
          encoding: {
            x: { field: cat, type:'nominal', sort:'-y' },
            y: { field: val, type:'quantitative' },
            tooltip: [{field:cat,type:'nominal'},{field:val,type:'quantitative'}]
          }
        },
        type: 'bar',
        x: cat, y: val
      };
    }
  }

  // Fallback: table-like dot plot of first two columns
  const a = headers[0], b = headers[1] || headers[0];
  return {
    spec: {
      $schema: 'https://vega.github.io/schema/vega-lite/v5.json',
      data: { values: rows },
      mark: 'point',
      encoding: { x:{field:a, type:'nominal'}, y:{field:b, type:'nominal'} }
    },
    type:'point', x:a, y:b
  };
}

async function renderPreview(spec) {
  const el = document.getElementById('vis');
  el.innerHTML = ''; // clear
  const result = await vegaEmbed('#vis', spec, { actions:false });
  return result;
}

// Random background by style
function pickBackground(style) {
  const pool = {
    tech: ['assets/bg-tech-1.png','assets/bg-tech-2.png'],
    apple: ['assets/bg-tech-2.png','assets/bg-tech-1.png'], // demo复用
    enterprise: ['assets/bg-tech-1.png','assets/bg-tech-2.png']
  };
  const arr = pool[style] || pool['tech'];
  return arr[Math.floor(Math.random()*arr.length)];
}

// Generate PPTX
async function exportPPT(pngDataUrl, meta) {
  const pptx = new PptxGenJS();
  // Define a simple slide master per style
  const bg = pickBackground(meta.style);
  pptx.defineSlideMaster({
    title: "DeptMaster",
    background: { path: bg },
    objects: [
      { image: { path: "assets/logo.png", x:0.2, y:6.8, w:1.4, h:0.42 } }
    ]
  });

  // Cover slide
  let cover = pptx.addSlide({ masterName: "DeptMaster" });
  cover.addText(meta.title || "自动生成报告", { x:0.6, y:0.6, fontSize:32, bold:true, color:'FFFFFF' });
  cover.addText(new Date().toLocaleDateString(), { x:0.6, y:1.2, fontSize:14, color:'FFFFFF' });

  // Chart slide (full)
  let s1 = pptx.addSlide({ masterName: "DeptMaster" });
  s1.addText(meta.chartTitle || "AI 推荐图表", { x:0.6, y:0.5, fontSize:24, bold:true, color:'FFFFFF' });
  s1.addImage({ data: pngDataUrl, x:0.6, y:1.1, w:8.0 });

  // Bullet slide from desc
  const bullets = (meta.desc||'').split('\n').map(t=>t.replace(/^[-•·\s]+/,'').trim()).filter(Boolean);
  if (bullets.length) {
    let s2 = pptx.addSlide({ masterName: "DeptMaster" });
    s2.addText("关键要点", { x:0.6, y:0.5, fontSize:24, bold:true, color:'FFFFFF' });
    s2.addText(bullets.map(b=>({ text: b+"\n", options:{ bullet:true, fontSize:18, color:'FFFFFF' } })), { x:0.9, y:1.2, w:8.0, h:4.5 });
  }

  await pptx.writeFile({ fileName: "report.pptx" });
}

let lastPng = null;

document.getElementById('btnPreview').addEventListener('click', async () => {
  const statusEl = document.getElementById('vis');
  const file = document.getElementById('csv').files[0];
  let text = '';
  if (!file) {
    try {
      statusEl.innerHTML = '未选择文件，正在加载示例数据 sample.csv ...';
      const resp = await fetch('sample.csv');
      text = await resp.text();
    } catch (e) {
      alert('无法加载示例数据，请检查解压目录是否包含 sample.csv');
      return;
    }
  } else {
    text = await file.text();
  }
  const {headers, rows} = parseCSV(text);
  if (headers.length<1 || rows.length<1) { alert('CSV 内容为空'); return; }
  const types = profileColumns(headers, rows);
  const rec = recommendSpec(headers, rows, types);
  const res = await renderPreview(rec.spec);
  const dataUrl = await res.view.toImageURL('png');
  statusEl.insertAdjacentHTML('beforeend','<div style="position:absolute;right:12px;bottom:8px;font-size:12px;color:#64748b;">图表类型: '+rec.type+'</div>');
  lastPng = dataUrl;
  document.getElementById('btnPPT').disabled = false;
});

document.getElementById('btnPPT').addEventListener('click', async () => {
  if (!lastPng) { alert('请先生成预览图表'); return; }
  const meta = {
    style: document.getElementById('style').value,
    title: document.getElementById('title').value,
    desc: document.getElementById('desc').value,
    chartTitle: 'AI 推荐图表'
  };
  await exportPPT(lastPng, meta);
});


/* expose smoke generator for CI */
window.__smokeGenerate = async function(){
  try{
    const input = document.getElementById('csv');
    let text = '';
    if (input && input.files && input.files[0]) {
      text = await input.files[0].text();
    } else {
      const resp = await fetch('sample.csv'); text = await resp.text();
    }
    if (typeof generateFromCSV === 'function') {
      window.__lastPng = await generateFromCSV(text);
    } else {
      const btn = document.getElementById('btnPreview'); btn && btn.click();
    }
  }catch(e){ console.error('smokeGenerate failed', e); }
};
