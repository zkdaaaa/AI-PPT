# PPT AI Demo (本地可运行的最小可用版)

打开 `index.html` 即可。
流程：
1. 选择风格（科技风/苹果风/企业风）
2. 填写标题、描述
3. 上传 CSV 数据（示例见 sample.csv）
4. 点击【生成 PPT】预览图表并下载 PPTX

说明：
- 本 Demo 会根据数据自动推荐图表（日期→折线；分类+数值→柱状；少量占比→饼图）。
- 背景从 assets/ 随机选择，确保每次不同。
- 生成逻辑纯前端：Vega-Lite 渲染图并导出 PNG，PptxGenJS 生成 PPTX。
- 你可以把公司模板风格复刻为 SlideMaster，或后续切换到 Docxtemplater 直接吃 .pptx 模板。

建议：
- 将公司图库（背景/图标）放入 assets/，文件名按风格前缀分类，如 bg-tech-*.png。
